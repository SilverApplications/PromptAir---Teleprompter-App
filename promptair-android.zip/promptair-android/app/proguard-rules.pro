# WebView-JS-Bridge nicht wegoptimieren
-keepclassmembers class de.promptair.app.SpeechBridge { public *; }
