package de.promptair.app.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/** Ergebnis der Qualitaetspruefung einer Anker-Aufnahme. */
data class QualityReport(
    val durationSec: Float,
    val rmsDb: Float,          // mittlerer Pegel
    val peak: Float,           // 0..1
    val clippedRatio: Float,   // Anteil uebersteuerter Samples
    val ok: Boolean,
    val message: String
)

/**
 * Nimmt Mono-PCM mit 24 kHz / 16 bit auf - das Rohformat, das gaengige
 * Klonmodelle (F5-TTS, XTTS, StyleTTS 2) als Trainings-/Referenzmaterial erwarten.
 * Bewusst unkomprimiert: Das Ankermaterial ist der wertvollste Datenbestand
 * und soll fuer zukuenftige, bessere Modelle wiederverwendbar bleiben.
 */
class WavRecorder {

    companion object {
        const val SAMPLE_RATE = 24000
    }

    private var record: AudioRecord? = null
    @Volatile private var running = false
    private val pcm = ByteArrayOutputStream()

    /** Live-Pegel 0..1 fuer die Anzeige waehrend der Aufnahme. */
    @Volatile var level: Float = 0f
        private set

    @SuppressLint("MissingPermission") // Berechtigung prueft die Activity vorab
    fun start() {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        pcm.reset()
        record = AudioRecord(
            MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, 8192)
        ).also { it.startRecording() }
        running = true

        Thread {
            val buf = ShortArray(2048)
            while (running) {
                val n = record?.read(buf, 0, buf.size) ?: break
                if (n > 0) {
                    var peak = 0
                    val bytes = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until n) {
                        bytes.putShort(buf[i])
                        val a = abs(buf[i].toInt()); if (a > peak) peak = a
                    }
                    level = peak / 32768f
                    synchronized(pcm) { pcm.write(bytes.array()) }
                }
            }
        }.start()
    }

    /** Stoppt, schreibt die WAV-Datei und liefert den Qualitaetsbericht. */
    fun stopAndSave(target: File): QualityReport {
        running = false
        record?.let { runCatching { it.stop() }; it.release() }
        record = null

        val data = synchronized(pcm) { pcm.toByteArray() }
        writeWav(target, data)
        return analyze(data)
    }

    fun discard() {
        running = false
        record?.let { runCatching { it.stop() }; it.release() }
        record = null
        pcm.reset()
    }

    private fun writeWav(file: File, pcmData: ByteArray) {
        FileOutputStream(file).use { out ->
            val totalLen = 36 + pcmData.size
            val byteRate = SAMPLE_RATE * 2
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt(totalLen); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
            h.putInt(SAMPLE_RATE); h.putInt(byteRate); h.putShort(2); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(pcmData.size)
            out.write(h.array()); out.write(pcmData)
        }
    }

    private fun analyze(pcmData: ByteArray): QualityReport {
        val bb = ByteBuffer.wrap(pcmData).order(ByteOrder.LITTLE_ENDIAN)
        val n = pcmData.size / 2
        if (n < SAMPLE_RATE / 2) {
            return QualityReport(n.toFloat() / SAMPLE_RATE, -120f, 0f, 0f, false,
                "Aufnahme zu kurz - bitte den Satz vollstaendig sprechen.")
        }
        var sumSq = 0.0; var peak = 0; var clipped = 0
        for (i in 0 until n) {
            val s = bb.getShort(i * 2).toInt()
            sumSq += s.toDouble() * s
            val a = abs(s); if (a > peak) peak = a
            if (a >= 32700) clipped++
        }
        val rms = sqrt(sumSq / n)
        val rmsDb = (20 * log10(rms / 32768.0)).toFloat()
        val clippedRatio = clipped.toFloat() / n
        val dur = n.toFloat() / SAMPLE_RATE

        val (ok, msg) = when {
            clippedRatio > 0.002f -> false to "Uebersteuert - bitte etwas mehr Abstand zum Mikrofon."
            rmsDb < -38f -> false to "Zu leise - bitte lauter oder naeher am Mikrofon sprechen."
            else -> true to "Aufnahme in Ordnung."
        }
        return QualityReport(dur, rmsDb, peak / 32768f, clippedRatio, ok, msg)
    }
}
