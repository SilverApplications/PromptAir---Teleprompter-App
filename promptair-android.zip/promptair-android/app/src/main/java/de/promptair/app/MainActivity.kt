package de.promptair.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

/**
 * Hostet den fertigen Web-Prompter (assets/promptair.html) in einem WebView.
 *
 * Warum so? Der Prompter ist als Web-Oberflaeche bereits komplett und getestet.
 * Der WebViewAssetLoader liefert ihn unter https://appassets.androidplatform.net
 * aus - ein "sicherer Kontext", damit Kamera/Mikrofon-APIs funktionieren.
 * Die Spracherkennung laeuft NICHT ueber die (im WebView fehlende) Web Speech API,
 * sondern nativ ueber [SpeechBridge] und wird per JS-Polyfill in die Seite gereicht.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var speech: SpeechBridge
    private var pendingWebPermission: PermissionRequest? = null

    private val askPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        // Web-seitige Anfrage (getUserMedia) beantworten, falls eine offen ist
        pendingWebPermission?.let { req ->
            val allGranted = grants.values.all { it }
            if (allGranted) req.grant(req.resources) else req.deny()
            pendingWebPermission = null
        }
        // Spracherkennung nachholen, falls sie auf die Berechtigung gewartet hat
        if (grants[Manifest.permission.RECORD_AUDIO] == true) speech.onPermissionGranted()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        supportActionBar?.title = getString(R.string.app_name)

        speech = SpeechBridge(this, web) { needsPermission ->
            if (needsPermission) askPermissions.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        web.addJavascriptInterface(speech, "AndroidSpeech")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                // Kamera/Mikro-Anfragen der Seite -> native Laufzeit-Berechtigungen
                val needed = mutableListOf<String>()
                request.resources.forEach { res ->
                    when (res) {
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                            if (!has(Manifest.permission.RECORD_AUDIO)) needed += Manifest.permission.RECORD_AUDIO
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                            if (!has(Manifest.permission.CAMERA)) needed += Manifest.permission.CAMERA
                    }
                }
                if (needed.isEmpty()) {
                    runOnUiThread { request.grant(request.resources) }
                } else {
                    pendingWebPermission = request
                    askPermissions.launch(needed.toTypedArray())
                }
            }
        }

        web.loadUrl("https://appassets.androidplatform.net/assets/promptair.html")
    }

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, getString(R.string.synthair_title))
            .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == 1) {
            startActivity(Intent(this, SynthAirActivity::class.java)); return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        speech.destroy()
        web.destroy()
        super.onDestroy()
    }
}
