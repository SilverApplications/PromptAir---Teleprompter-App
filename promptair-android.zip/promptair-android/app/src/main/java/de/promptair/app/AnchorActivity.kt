package de.promptair.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import de.promptair.app.audio.WavRecorder
import de.promptair.app.store.ProfileStore
import java.io.File

/**
 * Das Ankerprogramm (max. 5 Minuten), Aufbau laut Konzept, Abschnitt 5:
 *  - 15 phonetisch ausgewogene Saetze (alle deutschen Laute, Frage/Ausruf/Zahlen)
 *  - 2 Abschnitte freie Rede (Sprechrhythmus, Pausen, Fuellwoerter des Nutzers)
 *  - 1 gesprochener Einverstaendnissatz (rechtliche Absicherung + Klon-Huerde)
 * Jede Aufnahme wird sofort auf Pegel, Uebersteuerung und Laenge geprueft
 * und bei Bedarf gezielt wiederholt - nicht erst am Ende alles verworfen.
 */
class AnchorActivity : AppCompatActivity() {

    private data class Item(val kind: String, val text: String, val minSec: Float)

    private val items: List<Item> by lazy {
        val read = listOf(
            "Guten Morgen, heute zeigen wir die wichtigsten Zahlen des Quartals.",
            "Können Sie mir bitte kurz erklären, wie das funktioniert?",
            "Das ist wirklich eine außergewöhnlich gute Nachricht!",
            "Zwischen München und Zürich fährt der Zug über Bregenz.",
            "Die Böschung wächst über die schräge Brücke hinaus.",
            "Am fünfundzwanzigsten Juli um sechzehn Uhr dreißig beginnt das Meeting.",
            "Physik, Chemie und Psychologie gehören zu meinen Lieblingsfächern.",
            "Quatsch keine Opern, sondern komm endlich zum Punkt.",
            "Der jährliche Umsatz stieg um zwölf Komma sieben Prozent.",
            "Wollen wir das Projekt gemeinsam durchziehen oder lieber verschieben?",
            "Achtung: Diese Änderung betrifft ausschließlich externe Kunden.",
            "Ein junger Jäger jagte gähnend durch das joviale Dorf.",
            "Trotzdem bleibt die Situation angespannt und schwer vorhersehbar.",
            "Hurra, wir haben das Ziel drei Wochen früher erreicht!",
            "Zum Schluss bedanke ich mich herzlich für Ihre Aufmerksamkeit."
        ).map { Item("satz", it, 1.5f) }

        val free = listOf(
            Item("frei", "Freie Rede (ca. 45 Sekunden): Erzähl von deinem letzten Urlaub – einfach drauflos, mit allen Pausen und Ähms, die dir natürlich passieren.", 20f),
            Item("frei", "Freie Rede (ca. 45 Sekunden): Beschreibe, was du heute schon gemacht hast – so, als würdest du es einem Freund erzählen.", 20f)
        )
        val consent = Item("einverstaendnis",
            "Einverständnis (bitte wörtlich sprechen): „Ich erstelle hiermit ein synthetisches Abbild meiner eigenen Stimme und stimme dessen Nutzung in dieser App zu.“", 4f)

        read + free + listOf(consent)
    }

    private lateinit var store: ProfileStore
    private val recorder = WavRecorder()
    private var index = 0
    private var recording = false
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var txtProgress: TextView
    private lateinit var txtPrompt: TextView
    private lateinit var txtFeedback: TextView
    private lateinit var barLevel: ProgressBar
    private lateinit var btnRecord: Button

    private val askMic = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) toggleRecord() else finish() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_anchor)
        store = ProfileStore(this)

        txtProgress = findViewById(R.id.txtProgress)
        txtPrompt = findViewById(R.id.txtPrompt)
        txtFeedback = findViewById(R.id.txtFeedback)
        barLevel = findViewById(R.id.barLevel)
        btnRecord = findViewById(R.id.btnRecord)

        btnRecord.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) askMic.launch(Manifest.permission.RECORD_AUDIO)
            else toggleRecord()
        }
        showItem()
        tickLevel()
    }

    private fun showItem() {
        val it = items[index]
        txtProgress.text = getString(R.string.anchor_progress, index + 1, items.size)
        txtPrompt.text = it.text
        txtFeedback.text = when (it.kind) {
            "frei" -> getString(R.string.anchor_hint_free)
            "einverstaendnis" -> getString(R.string.anchor_hint_consent)
            else -> getString(R.string.anchor_hint_read)
        }
    }

    private fun toggleRecord() {
        if (!recording) {
            recorder.start()
            recording = true
            btnRecord.text = getString(R.string.anchor_stop)
            txtFeedback.text = getString(R.string.anchor_recording)
        } else {
            recording = false
            btnRecord.text = getString(R.string.anchor_record)
            val tmp = File(cacheDir, "anchor_tmp.wav")
            val report = recorder.stopAndSave(tmp)
            val item = items[index]

            if (!report.ok || report.durationSec < item.minSec) {
                txtFeedback.text = if (report.durationSec < item.minSec)
                    getString(R.string.anchor_too_short) else report.message
                tmp.delete()
                return
            }
            store.importRecording(tmp, index, item.kind)
            if (item.kind == "einverstaendnis") store.markConsentGiven()

            if (index < items.size - 1) {
                index++
                showItem()
                txtFeedback.append("\n" + getString(R.string.anchor_saved))
            } else {
                txtPrompt.text = getString(R.string.anchor_done)
                txtFeedback.text = getString(R.string.anchor_done_hint)
                btnRecord.isEnabled = false
            }
        }
    }

    /** Live-Pegelanzeige waehrend der Aufnahme. */
    private fun tickLevel() {
        barLevel.progress = (recorder.level * 100).toInt()
        ui.postDelayed({ tickLevel() }, 80)
    }

    override fun onDestroy() {
        if (recording) recorder.discard()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
