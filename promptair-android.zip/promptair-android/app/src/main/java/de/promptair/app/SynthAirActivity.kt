package de.promptair.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import de.promptair.app.store.ProfileStore
import de.promptair.app.tts.CloneEngine

/** Startpunkt des SynthAir-Moduls: Profilstatus, Ankerprogramm, Wiedergabe. */
class SynthAirActivity : AppCompatActivity() {

    private lateinit var store: ProfileStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_synthair)
        store = ProfileStore(this)

        findViewById<Button>(R.id.btnAnchor).setOnClickListener {
            startActivity(Intent(this, AnchorActivity::class.java))
        }
        findViewById<Button>(R.id.btnSpeak).setOnClickListener {
            startActivity(Intent(this, SpeakActivity::class.java))
        }
        findViewById<Button>(R.id.btnDelete).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.delete_profile)
                .setMessage(R.string.delete_profile_confirm)
                .setPositiveButton(R.string.delete) { _, _ ->
                    store.deleteProfile(); refresh()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val status = findViewById<TextView>(R.id.txtStatus)
        val n = store.recordingCount()
        status.text = when {
            store.isProfileComplete() ->
                getString(R.string.profile_complete, n) + "\n\n" + CloneEngine.STATUS
            n > 0 ->
                getString(R.string.profile_partial, n)
            else ->
                getString(R.string.profile_empty)
        }
    }
}
