package de.promptair.app

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import de.promptair.app.tts.PiperEngine
import de.promptair.app.tts.SystemTtsEngine
import de.promptair.app.tts.TtsEngine
import de.promptair.app.tts.VoiceInfo
import java.io.File

/**
 * Wiedergabe beliebiger Texte ueber die Engine-Abstraktion.
 * Die Stimmenliste kombiniert alle verfuegbaren Backends:
 * zuerst die Piper-Stimmen (sofern Modelle in assets/models liegen),
 * dahinter die System-TTS-Stimmen als immer verfuegbarer Fallback.
 */
class SpeakActivity : AppCompatActivity() {

    private lateinit var engine: SystemTtsEngine
    private lateinit var piper: PiperEngine
    private var voiceList: List<VoiceInfo> = emptyList()
    private var rate = 1.0f

    /** Routet einen Stimmen-Eintrag zum passenden Backend. */
    private fun engineFor(v: VoiceInfo): TtsEngine =
        if (v.id.startsWith("piper:")) piper else engine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_speak)

        val spinner = findViewById<Spinner>(R.id.spVoice)
        val input = findViewById<EditText>(R.id.edText)
        val rateLabel = findViewById<TextView>(R.id.txtRate)

        piper = PiperEngine(this)
        engine = SystemTtsEngine(this) {
            runOnUiThread {
                // Piper-Stimmen zuerst (die hochwertigen Offline-Stimmen),
                // System-TTS dahinter als Fallback
                voiceList = piper.voices() + engine.voices()
                spinner.adapter = ArrayAdapter(
                    this, android.R.layout.simple_spinner_dropdown_item,
                    if (voiceList.isEmpty()) listOf(getString(R.string.no_voices))
                    else voiceList.map { it.label }
                )
            }
        }

        findViewById<SeekBar>(R.id.seekRate).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                    rate = 0.5f + p / 100f * 1.5f
                    rateLabel.text = getString(R.string.rate_label, rate)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })

        findViewById<Button>(R.id.btnSay).setOnClickListener {
            val v = voiceList.getOrNull(spinner.selectedItemPosition) ?: return@setOnClickListener
            piper.stop(); engine.stop()
            if (v.id.startsWith("piper:"))
                Toast.makeText(this, R.string.piper_generating, Toast.LENGTH_SHORT).show()
            engineFor(v).speak(input.text.toString(), v.id, rate) {}
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener { piper.stop(); engine.stop() }

        findViewById<Button>(R.id.btnExport).setOnClickListener {
            val v = voiceList.getOrNull(spinner.selectedItemPosition) ?: return@setOnClickListener
            val out = File(getExternalFilesDir(null), "PromptAir_TTS_${System.currentTimeMillis()}.wav")
            engineFor(v).synthesizeToFile(input.text.toString(), v.id, rate, out) { ok ->
                runOnUiThread {
                    if (!ok) { Toast.makeText(this, R.string.export_failed, Toast.LENGTH_SHORT).show(); return@runOnUiThread }
                    val uri = FileProvider.getUriForFile(this, "$packageName.files", out)
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "audio/wav"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, getString(R.string.share_audio)))
                }
            }
        }
    }

    override fun onDestroy() {
        piper.release()
        engine.release()
        super.onDestroy()
    }
}
