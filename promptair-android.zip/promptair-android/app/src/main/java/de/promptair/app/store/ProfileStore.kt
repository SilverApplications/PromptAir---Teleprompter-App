package de.promptair.app.store

import android.content.Context
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Verschluesselter Profilspeicher fuer das SynthAir-Stimmprofil.
 *
 * Ein Stimmprofil ist nach DSGVO ein biometrisches Datum (Art. 9).
 * Deshalb: Ablage ausschliesslich im privaten App-Verzeichnis, verschluesselt
 * mit einem Schluessel aus dem Android Keystore (AES256-GCM). Selbst mit
 * Dateisystemzugriff (Root/Backup) sind die Aufnahmen nicht lesbar.
 *
 * Struktur:
 *   files/synthair/anchor_XX.wav.enc   verschluesselte Rohaufnahmen
 *   files/synthair/profile.json.enc    Metadaten inkl. Einverstaendnisnachweis
 */
class ProfileStore(private val context: Context) {

    private val dir: File = File(context.filesDir, "synthair").apply { mkdirs() }

    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    private fun encrypted(file: File): EncryptedFile =
        EncryptedFile.Builder(
            context, file, masterKey,
            EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()

    /** Verschluesselt eine frisch aufgenommene WAV-Datei und loescht das Klartext-Original. */
    fun importRecording(plainWav: File, index: Int, kind: String) {
        val target = File(dir, "anchor_%02d.wav.enc".format(index))
        if (target.exists()) target.delete()
        encrypted(target).openFileOutput().use { out ->
            plainWav.inputStream().use { it.copyTo(out) }
        }
        plainWav.delete()

        val meta = loadMeta()
        val recs = meta.optJSONArray("recordings") ?: JSONArray()
        // vorhandenen Eintrag fuer diesen Index ersetzen
        val kept = JSONArray()
        for (i in 0 until recs.length()) {
            val r = recs.getJSONObject(i)
            if (r.getInt("index") != index) kept.put(r)
        }
        kept.put(JSONObject().put("index", index).put("kind", kind)
            .put("file", target.name).put("ts", System.currentTimeMillis()))
        meta.put("recordings", kept)
        saveMeta(meta)
    }

    /** Entschluesselt eine Aufnahme in eine temporaere Datei (z. B. fuer die Klon-Engine). */
    fun exportRecording(index: Int): File? {
        val src = File(dir, "anchor_%02d.wav.enc".format(index))
        if (!src.exists()) return null
        val tmp = File(context.cacheDir, "anchor_%02d.wav".format(index))
        encrypted(src).openFileInput().use { input ->
            tmp.outputStream().use { input.copyTo(it) }
        }
        return tmp
    }

    fun recordingCount(): Int = loadMeta().optJSONArray("recordings")?.length() ?: 0

    fun markConsentGiven() {
        saveMeta(loadMeta().put("consentTs", System.currentTimeMillis()))
    }

    fun isProfileComplete(): Boolean {
        val m = loadMeta()
        return m.has("consentTs") && (m.optJSONArray("recordings")?.length() ?: 0) >= 15
    }

    /** Loescht Profil und alle Rohaufnahmen rueckstandsfrei. */
    fun deleteProfile() {
        dir.listFiles()?.forEach { it.delete() }
    }

    private val metaFile get() = File(dir, "profile.json.enc")

    private fun loadMeta(): JSONObject {
        if (!metaFile.exists()) return JSONObject()
        return runCatching {
            encrypted(metaFile).openFileInput().use {
                JSONObject(it.readBytes().decodeToString())
            }
        }.getOrElse { JSONObject() }
    }

    private fun saveMeta(meta: JSONObject) {
        if (metaFile.exists()) metaFile.delete()
        encrypted(metaFile).openFileOutput().use {
            it.write(meta.toString().encodeToByteArray())
        }
    }
}
