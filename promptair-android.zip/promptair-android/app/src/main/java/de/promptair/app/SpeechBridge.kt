package de.promptair.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * Bruecke zwischen dem Web-Prompter und der nativen Android-Spracherkennung.
 *
 * Die Seite ruft AndroidSpeech.start(lang) / AndroidSpeech.stop() auf;
 * erkannte (Teil-)Saetze werden per window.__onSpeech(text, isFinal)
 * zurueckgereicht. Die Erkennung startet sich im Dauerbetrieb selbst neu,
 * da Androids SpeechRecognizer nach jeder Aeusserung endet.
 */
class SpeechBridge(
    private val activity: Activity,
    private val web: WebView,
    private val requestPermission: (Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var active = false
    private var lang = "de-DE"

    @JavascriptInterface
    fun start(language: String) {
        main.post {
            lang = language.ifBlank { "de-DE" }
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermission(true)
                return@post
            }
            active = true
            startListening()
        }
    }

    @JavascriptInterface
    fun stop() {
        main.post {
            active = false
            recognizer?.destroy()
            recognizer = null
        }
    }

    /** Wird von MainActivity gerufen, wenn die Berechtigung nachtraeglich erteilt wurde. */
    fun onPermissionGranted() {
        main.post { active = true; startListening() }
    }

    private fun startListening() {
        if (!active) return
        if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
            push("__promptairToast", "Keine Spracherkennung auf diesem Geraet verfuegbar.")
            active = false
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(activity).apply {
            setRecognitionListener(listener)
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            })
        }
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResults(partialResults: Bundle) {
            firstResult(partialResults)?.let { send(it, false) }
        }

        override fun onResults(results: Bundle) {
            firstResult(results)?.let { send(it, true) }
            if (active) main.postDelayed({ startListening() }, 120)
        }

        override fun onError(error: Int) {
            // Timeouts/No-Match sind im Dauerbetrieb normal -> einfach neu starten
            if (active) main.postDelayed({ startListening() }, 250)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun firstResult(b: Bundle): String? =
        b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

    private fun send(text: String, isFinal: Boolean) {
        val safe = JSONObject.quote(text)
        web.evaluateJavascript(
            "window.__onSpeech && window.__onSpeech($safe, $isFinal);", null
        )
    }

    private fun push(fn: String, msg: String) {
        val safe = JSONObject.quote(msg)
        web.evaluateJavascript("window.$fn && window.$fn($safe);", null)
    }

    fun destroy() {
        active = false
        recognizer?.destroy()
        recognizer = null
    }
}
