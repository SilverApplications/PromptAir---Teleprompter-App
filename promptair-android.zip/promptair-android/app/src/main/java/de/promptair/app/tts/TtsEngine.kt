package de.promptair.app.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.io.File
import java.util.Locale

/**
 * Gemeinsame Schnittstelle aller Sprachsynthese-Backends.
 * Der Rest der App kennt nur dieses Interface - die Engine (System-TTS,
 * sherpa-onnx/Piper, On-Device-Klonmodell, spaeter evtl. Cloud) ist austauschbar.
 */
interface TtsEngine {
    /** Verfuegbare Stimmen dieses Backends. */
    fun voices(): List<VoiceInfo>

    /** Spricht den Text direkt. [rate] 0.5..2.0. */
    fun speak(text: String, voiceId: String, rate: Float, onDone: () -> Unit)

    /** Synthese in eine WAV-Datei (fuer Export / PPT-Vertonung). */
    fun synthesizeToFile(text: String, voiceId: String, rate: Float, target: File, onDone: (Boolean) -> Unit)

    fun stop()
    fun release()
}

data class VoiceInfo(val id: String, val label: String, val engine: String)

/**
 * Backend 1: Android-System-TTS.
 * Liefert die beiden vorinstallierten Stimmen sofort und offline
 * (Google-TTS-Deutschstimmen sind auf praktisch jedem Geraet vorhanden).
 * Dient als Fallback, bis Piper-Stimmen ueber sherpa-onnx eingebunden sind.
 */
class SystemTtsEngine(context: Context, private val onReady: () -> Unit) : TtsEngine {

    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.GERMANY
            ready = true
            onReady()
        }
    }

    override fun voices(): List<VoiceInfo> {
        if (!ready) return emptyList()
        return tts.voices
            ?.filter { it.locale.language == "de" && !it.isNetworkConnectionRequired }
            ?.sortedBy { it.name }
            ?.map { VoiceInfo(it.name, prettyName(it), "System-TTS (offline)") }
            ?: emptyList()
    }

    private fun prettyName(v: Voice): String {
        // Google benennt Stimmen kryptisch (de-DE-x-deb-local etc.) und verraet
        // das Geschlecht nicht per API - daher neutral durchnummerieren.
        val idx = v.name.hashCode().let { if (it < 0) -it else it } % 97
        return "Deutsch - ${v.name.substringAfterLast("x-").substringBefore("-").uppercase()} ($idx)"
    }

    override fun speak(text: String, voiceId: String, rate: Float, onDone: () -> Unit) {
        applyVoice(voiceId, rate)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onDone(utteranceId: String?) = onDone()
            override fun onError(utteranceId: String?) = onDone()
            override fun onStart(utteranceId: String?) {}
        })
        // [pause]-Marker in echte Stille uebersetzen
        val parts = text.split(Regex("\\[pause( lang)?]"))
        val longPause = Regex("\\[pause lang]")
        var cursor = 0
        parts.forEachIndexed { i, part ->
            if (part.isNotBlank()) {
                tts.speak(part.trim(), TextToSpeech.QUEUE_ADD, null, "u$i")
            }
            if (i < parts.size - 1) {
                cursor += part.length
                val isLong = longPause.find(text, cursor) ?. range?.first == cursor
                tts.playSilentUtterance(if (isLong) 1200 else 500, TextToSpeech.QUEUE_ADD, "p$i")
                cursor += if (isLong) 12 else 7
            }
        }
    }

    override fun synthesizeToFile(text: String, voiceId: String, rate: Float, target: File, onDone: (Boolean) -> Unit) {
        applyVoice(voiceId, rate)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onDone(utteranceId: String?) = onDone(true)
            override fun onError(utteranceId: String?) = onDone(false)
            override fun onStart(utteranceId: String?) {}
        })
        tts.synthesizeToFile(text.replace(Regex("\\[pause( lang)?]"), ","), null, target, "file")
    }

    private fun applyVoice(voiceId: String, rate: Float) {
        tts.voices?.firstOrNull { it.name == voiceId }?.let { tts.voice = it }
        tts.setSpeechRate(rate)
    }

    override fun stop() { tts.stop() }
    override fun release() { tts.shutdown() }
}

/**
 * Backend 2 (Weg B - Anschlusspunkt): On-Device-Klonmodell.
 *
 * Integration laut Konzept, Abschnitt 4:
 *  1. sherpa-onnx-Abhaengigkeit in app/build.gradle.kts einkommentieren.
 *  2. Modelldateien nach files/models/ legen (Details im README):
 *     - Piper de_DE (Mann + Frau) fuer die vorinstallierten Stimmen,
 *     - Klonmodell (z. B. F5-TTS im ONNX-Export) fuer die eigene Stimme.
 *  3. Referenzaudio aus [de.promptair.app.store.ProfileStore.exportRecording]
 *     als Sprecher-Embedding an das Modell geben.
 *
 * Diese Klasse meldet bis dahin ehrlich "nicht verfuegbar", statt still
 * auf eine andere Stimme auszuweichen.
 */
class CloneEngine : TtsEngine {
    override fun voices(): List<VoiceInfo> = emptyList()
    override fun speak(text: String, voiceId: String, rate: Float, onDone: () -> Unit) = onDone()
    override fun synthesizeToFile(text: String, voiceId: String, rate: Float, target: File, onDone: (Boolean) -> Unit) = onDone(false)
    override fun stop() {}
    override fun release() {}

    companion object {
        const val STATUS =
            "Klonmodell noch nicht eingebunden. Das Ankerprogramm kann bereits " +
            "durchgefuehrt werden - die Aufnahmen liegen verschluesselt bereit " +
            "und werden von der Klon-Engine verwendet, sobald das Modell " +
            "installiert ist (siehe README, Abschnitt 'Klonmodell einbinden')."
    }
}
