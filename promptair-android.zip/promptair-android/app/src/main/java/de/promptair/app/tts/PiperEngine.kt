package de.promptair.app.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Backend 2: Piper-Stimmen ueber sherpa-onnx (Weg B, vollstaendig offline).
 *
 * Erwartete Ablage in app/src/main/assets/:
 *   models/thorsten/<*.onnx> + tokens.txt     (maennliche Stimme)
 *   models/eva/<*.onnx>      + tokens.txt     (weibliche Stimme)
 *   models/espeak-ng-data/                    (einmal, von beiden geteilt)
 *
 * Die Dateien stammen aus den sherpa-onnx-TTS-Paketen (siehe README,
 * Abschnitt "Piper-Stimmen einlegen"). Fehlen die Modelle, liefert
 * voices() eine leere Liste - die App laeuft dann unveraendert mit
 * System-TTS weiter. Beim ersten Start werden die Assets einmalig nach
 * filesDir kopiert, weil espeak-ng echte Dateipfade benoetigt.
 */
class PiperEngine(private val context: Context) : TtsEngine {

    private data class Def(val id: String, val label: String, val dir: String)

    private val defs = listOf(
        Def("piper:thorsten", "Thorsten – männlich (PromptAir, offline)", "thorsten"),
        Def("piper:eva", "Eva – weiblich (PromptAir, offline)", "eva")
    )

    private val cache = mutableMapOf<String, OfflineTts>()
    @Volatile private var track: AudioTrack? = null
    @Volatile private var speaking = false

    /** Nur Stimmen melden, deren Modelldateien tatsaechlich in den Assets liegen. */
    override fun voices(): List<VoiceInfo> = defs.filter { assetVoiceExists(it.dir) }
        .map { VoiceInfo(it.id, it.label, "Piper") }

    private fun assetVoiceExists(dir: String): Boolean = runCatching {
        val files = context.assets.list("models/$dir") ?: return false
        files.any { it.endsWith(".onnx") } && files.contains("tokens.txt")
    }.getOrDefault(false)

    // ---------- Initialisierung ----------

    private fun ttsFor(voiceId: String): OfflineTts? {
        cache[voiceId]?.let { return it }
        val def = defs.firstOrNull { it.id == voiceId } ?: return null
        if (!assetVoiceExists(def.dir)) return null

        val root = ensureModelsCopied() ?: return null
        val vDir = File(root, def.dir)
        val onnx = vDir.listFiles()?.firstOrNull { it.name.endsWith(".onnx") } ?: return null
        val tokens = File(vDir, "tokens.txt")
        val espeak = File(root, "espeak-ng-data")
        if (!tokens.exists() || !espeak.exists()) return null

        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                vits = OfflineTtsVitsModelConfig(
                    model = onnx.absolutePath,
                    tokens = tokens.absolutePath,
                    dataDir = espeak.absolutePath
                ),
                numThreads = 2,
                debug = false,
                provider = "cpu"
            )
        )
        return runCatching { OfflineTts(config = config) }
            .getOrNull()?.also { cache[voiceId] = it }
    }

    /** Kopiert assets/models einmalig nach filesDir/models (espeak braucht echte Pfade). */
    private fun ensureModelsCopied(): File? = runCatching {
        val root = File(context.filesDir, "models")
        val marker = File(root, ".copied")
        if (!marker.exists()) {
            copyAssetDir("models", root)
            marker.writeText("1")
        }
        root
    }.getOrNull()

    private fun copyAssetDir(assetPath: String, target: File) {
        val list = context.assets.list(assetPath) ?: return
        if (list.isEmpty()) { // Datei
            target.parentFile?.mkdirs()
            context.assets.open(assetPath).use { inp ->
                FileOutputStream(target).use { inp.copyTo(it) }
            }
        } else {              // Verzeichnis
            target.mkdirs()
            list.forEach { copyAssetDir("$assetPath/$it", File(target, it)) }
        }
    }

    // ---------- Synthese ----------

    /** Erzeugt Samples inkl. [pause]/[pause lang]-Markern. */
    private fun generate(text: String, voiceId: String, rate: Float): Pair<FloatArray, Int>? {
        val tts = ttsFor(voiceId) ?: return null
        val parts = text.split(Regex("(?=\\[pause( lang)?])|(?<=\\[pause])|(?<=\\[pause lang])"))
        val chunks = mutableListOf<FloatArray>()
        var sampleRate = 22050
        for (raw in parts) {
            val p = raw.trim()
            if (p.isEmpty()) continue
            if (p == "[pause]" || p == "[pause lang]") {
                val sec = if (p == "[pause lang]") 1.2f else 0.5f
                chunks += FloatArray((sampleRate * sec).toInt())
            } else {
                val audio = runCatching { tts.generate(text = p, sid = 0, speed = rate) }
                    .getOrNull() ?: continue
                sampleRate = audio.sampleRate
                chunks += audio.samples
            }
        }
        if (chunks.isEmpty()) return null
        val total = FloatArray(chunks.sumOf { it.size })
        var pos = 0
        chunks.forEach { it.copyInto(total, pos); pos += it.size }
        return total to sampleRate
    }

    override fun speak(text: String, voiceId: String, rate: Float, onDone: () -> Unit) {
        stop()
        speaking = true
        Thread {
            val result = generate(text, voiceId, rate)
            if (result == null || !speaking) { speaking = false; onDone(); return@Thread }
            val (samples, sr) = result
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(samples.size * 4)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track = t
            t.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
            t.setNotificationMarkerPosition(samples.size)
            t.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(tr: AudioTrack?) { speaking = false; onDone() }
                override fun onPeriodicNotification(tr: AudioTrack?) {}
            })
            t.play()
        }.start()
    }

    override fun synthesizeToFile(text: String, voiceId: String, rate: Float, target: File, onDone: (Boolean) -> Unit) {
        Thread {
            val result = generate(text, voiceId, rate)
            if (result == null) { onDone(false); return@Thread }
            val (samples, sr) = result
            runCatching { writeWav16(target, samples, sr) }
                .onSuccess { onDone(true) }.onFailure { onDone(false) }
        }.start()
    }

    private fun writeWav16(file: File, samples: FloatArray, sr: Int) {
        val pcm = ByteBuffer.allocate(samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (s in samples) {
            val v = (s.coerceIn(-1f, 1f) * 32767).toInt()
            pcm.putShort(v.toShort())
        }
        FileOutputStream(file).use { out ->
            val data = pcm.array()
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt(36 + data.size); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
            h.putInt(sr); h.putInt(sr * 2); h.putShort(2); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(data.size)
            out.write(h.array()); out.write(data)
        }
    }

    override fun stop() {
        speaking = false
        track?.let { runCatching { it.stop(); it.release() } }
        track = null
    }

    override fun release() {
        stop()
        cache.values.forEach { runCatching { it.release() } }
        cache.clear()
    }
}
