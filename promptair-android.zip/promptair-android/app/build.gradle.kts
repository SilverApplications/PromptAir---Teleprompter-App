plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.promptair.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "de.promptair.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.webkit:webkit:1.10.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.activity:activity-ktx:1.8.2")

    // SynthAir Stufe 2 (Weg B, On-Device-Klonmodelle):
    // sherpa-onnx liefert die ONNX-Laufzeit fuer lokale TTS-Modelle (z. B. Piper-Stimmen,
    // spaeter Klonmodelle wie F5-TTS im ONNX-Export). Einkommentieren, sobald Modelle
    // eingebunden werden - siehe README Abschnitt "Klonmodell einbinden".
    implementation("com.k2fsa.sherpa.onnx:sherpa-onnx:1.10.30")
}
