# PromptAir – native Android-App (Kotlin)

Teleprompter mit Sprachsteuerung + SynthAir-Modul (synthetische Stimmen, Weg B: On-Device-Klonmodelle).

## So baust du die App (einmalig ca. 15 Minuten)

1. [Android Studio](https://developer.android.com/studio) installieren (kostenlos, Windows/Mac/Linux).
2. Android Studio öffnen → **Open** → diesen Ordner (`promptair-android`) wählen.
3. Studio lädt beim ersten Öffnen automatisch Gradle und alle Abhängigkeiten (Internet nötig).
4. Android-Handy per USB anschließen, auf dem Handy **Entwickleroptionen → USB-Debugging** aktivieren.
5. Oben in Studio das Gerät auswählen → grüner **Run**-Pfeil. Die App installiert und startet sich.
6. Für eine weitergebbare APK: **Build → Build Bundle(s)/APK(s) → Build APK(s)**.

## Was schon funktioniert

**Prompter:** Der komplette Web-Prompter läuft im WebView unter einem sicheren
https-Origin – Mikrofon- und Kameraberechtigungen fragt die App nativ per
System-Dialog ab (das Problem der Browser-Version ist damit endgültig gelöst).
Die Spracherkennung läuft nativ über Androids `SpeechRecognizer` und wird per
JS-Bridge in den Prompter eingespeist (`SpeechBridge.kt`), da WebViews die Web
Speech API nicht unterstützen.

**SynthAir:** Ankerprogramm (15 Sätze + 2× freie Rede + Einverständnissatz) mit
Live-Pegelanzeige und sofortiger Qualitätsprüfung (Pegel, Übersteuerung, Länge).
Aufnahmen als 24-kHz-WAV, verschlüsselt mit Android-Keystore-Schlüssel
(`ProfileStore.kt`) – ein Stimmprofil ist ein biometrisches Datum (DSGVO Art. 9).
Textwiedergabe mit allen deutschen Offline-Stimmen des Geräts, Tempo-Regler,
`[pause]`-Markern und WAV-Export (`SpeakActivity.kt`).

## Piper-Stimmen einlegen (Weg B, Stufe 1 – FERTIG VORBEREITET)

Die Piper-Engine ist vollständig implementiert (`tts/PiperEngine.kt`), die
sherpa-onnx-Abhängigkeit ist in `app/build.gradle.kts` bereits aktiv.
Du musst nur noch die Modelldateien einlegen:

1. **Herunterladen** (fertig gepackt für sherpa-onnx, je ca. 60–120 MB):
   https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models
   - `vits-piper-de_DE-thorsten-high.tar.bz2` (Mann, sehr gute Qualität)
   - `vits-piper-de_DE-eva_k-x_low.tar.bz2` (Frau)
   Alternativ auf HuggingFace: `csukuangfj/vits-piper-de_DE-...`
2. **Entpacken** (Windows: z. B. mit 7-Zip, zweistufig .bz2 → .tar).
3. **Einsortieren** nach `app/src/main/assets/models/`:
   - `thorsten/` ← die `.onnx`-Datei + `tokens.txt` aus dem Thorsten-Paket
   - `eva/` ← die `.onnx`-Datei + `tokens.txt` aus dem Eva-Paket
   - `espeak-ng-data/` ← den kompletten gleichnamigen Ordner aus einem
     der Pakete (wird von beiden Stimmen geteilt, einmal reicht)
4. **Neu bauen** (Run). Die Stimmen „Thorsten – männlich" und
   „Eva – weiblich" erscheinen automatisch oben in der Stimmenliste.
   Fehlen die Modelle, läuft die App unverändert mit System-TTS weiter.

Ehrliche Einordnung: `thorsten-high` klingt ausgezeichnet; bei den weiblichen
deutschen Piper-Stimmen gibt es derzeit nur niedrigere Qualitätsstufen
(`eva_k-x_low`, Alternativen: `kerstin-low`, `ramona-low`) – hörbar
synthetischer als Thorsten. Falls Gradle die sherpa-onnx-Version nicht
findet: auf Maven Central nach `com.k2fsa.sherpa.onnx` suchen und die
Versionsnummer in `app/build.gradle.kts` anpassen.

## Klonmodell einbinden (Weg B, Stufe 2 – eigene Stimme)

1. Zero-Shot-Klonmodell im ONNX-Export einbinden
   (empfohlen: F5-TTS – liberale Lizenz; XTTS-v2 nur nicht-kommerziell!).
   Als Sprecher-Referenz dienen die Anker-Aufnahmen:
   `ProfileStore(context).exportRecording(i)` entschlüsselt sie temporär.
   Die Implementierung gehört in `tts/TtsEngine.kt` → Klasse `CloneEngine`
   (Muster: `PiperEngine.kt` kopieren und Modellaufruf ersetzen).
2. Realistische Erwartung: Erzeugung dauert auf aktuellen Oberklasse-Geräten
   einige Sekunden pro Satz. Kennzeichne den Modus in der UI als „experimentell".

## Wichtige Dateien

```
app/src/main/assets/promptair.html      kompletter Prompter (Web-Oberfläche)
app/src/main/java/de/promptair/app/
  MainActivity.kt      WebView-Host, Berechtigungen, Asset-Loader
  SpeechBridge.kt      native Spracherkennung → JS-Bridge
  SynthAirActivity.kt  SynthAir-Übersicht
  AnchorActivity.kt    geführtes 5-Minuten-Ankerprogramm
  SpeakActivity.kt     Textwiedergabe / Export
  audio/WavRecorder.kt 24-kHz-WAV-Aufnahme + Qualitätsanalyse
  store/ProfileStore.kt verschlüsselter Profilspeicher (Keystore)
  tts/TtsEngine.kt     Engine-Abstraktion, System-TTS, CloneEngine-Anschluss
  tts/PiperEngine.kt   Piper-Stimmen ueber sherpa-onnx (offline)
app/src/main/assets/models/  hier Piper-Modelle einlegen (s. o.)
```

## Rechtliches (Kurzfassung, siehe SynthAir-Konzept Abschnitt 7)

Nur die eigene Stimme klonen; der gesprochene Einverständnissatz im
Ankerprogramm ist Pflichtbestandteil. Erzeugte Audios nicht als echte
Aufnahmen ausgeben. Bei Veröffentlichung der App: Modell-Lizenzen prüfen
(XTTS-v2 = nicht-kommerziell) und ein Audio-Wasserzeichen ergänzen.
